#include <iostream>
#include <cstring>
#include <windows.h>
#include <fstream>
#include <conio.h>
#include <iomanip>
#include <cstdlib>
#include <string>
#include"Covid_Management.h"
#define TOTAL_VACCINE 400
using namespace std;

int main() {
    system("Color C");
    Admin var;
    var.menu();
}