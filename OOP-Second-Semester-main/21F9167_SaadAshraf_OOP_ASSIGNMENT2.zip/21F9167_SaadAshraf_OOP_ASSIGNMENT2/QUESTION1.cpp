#include<iostream>
#include<conio.h>
#include<stdio.h>
using namespace std;
class Bank
{
public:
	char name[20];
	char account_type[20];
	int account_number;
	int balance;
	void assign()
	{
		cout << "Enter the name of account owner:";
		cin >> name;
		cout << "Enter type of Account :";
		cin >> account_type;
		cout << "Enter account number:";
		cin >> account_number;
		cout << "Enter balance to deposit:";
		cin >> balance;
	}
	void deposit()
	{
		int bal;
		cout << "\nEnter the amout to deposit:";
		cin >> bal;
		balance += bal;
		cout << "\nAmount deposited successfuly\nYour New Balance is :" << balance;
	}
	void balancecheck()
	{
		int bal;
		cout << "\nYour balance :" << balance << "\nEnter amount to withdraw:";
		cin >> bal;
		if (bal <= balance)
		{
			balance -= bal;
			cout << "\nRemaining Balance:" << balance;
		}
		else
		{
			exit(0);
		}
	}
	void display()
	{
		cout << "\nName :";
		cout << name;
		cout << "\nBalance :" << balance;
		cout << "\n Account number :" << account_number;
		cout << "\n Account Type : " << account_type;
	}
};
int main()
{
	int i;
	Bank n;
	n.assign();
	cout << "\n1. Your Information\n2. Deposit\n3. Withdraw\n\nEnter your choice : \n";
	cin >> i;
	if (i == 1)
	{
		n.display();
	}
	else if (i == 2)
	{
		n.deposit();
	}
	else if (i == 3)
	{
		n.balancecheck();
	}
}
