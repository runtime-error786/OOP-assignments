#include <iostream>
using namespace std;
int series(int x) {
    if ((x != 0) || (x != 1)) {
        return x;
    }
    else {
        return (series(x - 1) + series(x - 2));
    }
}
int main() {
    int x, i = 0;
    cout << "Enter the number upto which series is to be calculated : ";
    cin >> x;
    cout << "The Fibonnaci Series is : ";
    while (i < x) {
        cout << " " << series(i);
        i++;
    }
    return 0;
}
