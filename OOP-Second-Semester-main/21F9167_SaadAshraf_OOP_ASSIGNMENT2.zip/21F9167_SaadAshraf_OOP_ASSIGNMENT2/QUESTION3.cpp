#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
using namespace std;
class HotDogStand
{
private:
    int standsID;
    int hotDogsSold;
    static int totalHotDogsSold;
public:
    HotDogStand()
    {
        standsID = 0;
        hotDogsSold = 0;
    }
    HotDogStand(int newStandID, int newHotDogsSold)
    {
        standsID = newStandID;
        hotDogsSold = newHotDogsSold;
        HotDogStand::totalHotDogsSold += newHotDogsSold;
    }
    void justSold()
    {
        hotDogsSold++;
        HotDogStand::totalHotDogsSold++;
    }
    int getHotDogsSold()
    {
        return hotDogsSold;
    }
    static int getTotalHotDogsSold()
    {
        return HotDogStand::totalHotDogsSold;
    }
    int getStandsID()
    {
        return standsID;
    }
    static void main(std::vector<std::string>& args)
    {
        int x, y, a, b, c, d;
        cin >> x;
        cin >> y;
        cin >> a;
        cin >> b;
        cin >> c;
        cin >> d;
        HotDogStand* dog1 = new HotDogStand(x, y);
        HotDogStand* dog2 = new HotDogStand(a, b);
        HotDogStand* dog3 = new HotDogStand(c, d);
        dog1->justSold();
        dog1->justSold();
        dog1->justSold();
        dog2->justSold();
        dog2->justSold();
        dog2->justSold();
        dog2->justSold();
        dog2->justSold();
        dog3->justSold();
        dog3->justSold();
        cout << "StandsID        Hot Dogs Sold" << endl;;
        cout << "-----------------------" << endl;
        cout << dog1->getStandsID() << "              " << dog1->getHotDogsSold() << endl;;
        cout << dog2->getStandsID() << "              " << dog2->getHotDogsSold() << endl;
        cout << dog3->getStandsID() << "              " << dog3->getHotDogsSold() << endl;
        cout << "The Total number of hot dogs sold by all hot dog stands: " + std::to_string(HotDogStand::getTotalHotDogsSold()) << endl;
    }
};
int HotDogStand::totalHotDogsSold = 0;
int main(int argc, char** argv) {
    std::vector<std::string> parameter(argv + 1, argv + argc);
    HotDogStand::main(parameter);
    return 0;
};
